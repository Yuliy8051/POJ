public class Kapibara extends Animal{
    @Override
    public void makeSound() {
        System.out.println("kwi-kwi");
    }
}
