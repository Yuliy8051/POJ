public abstract class Figura2D extends Figura{
    public Figura2D(int[] sides) {
        super(sides);
    }

    @Override
    public abstract int suma();

    @Override
    public abstract double pole();
}
