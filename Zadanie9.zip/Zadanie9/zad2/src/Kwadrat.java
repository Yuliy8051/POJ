public class Kwadrat extends Prostokat{
    public Kwadrat(int side) {
        super(side,side);
    }
}
