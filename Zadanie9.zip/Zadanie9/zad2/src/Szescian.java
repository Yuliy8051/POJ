public class Szescian extends Prostopadloscian{
    public Szescian(int side) {
        super(side, side, side);
    }
}
